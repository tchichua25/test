#CLI - Command line Interface Simulation

A fun experiment for displaying simple onepage info in a geeky manner using jQuery.

[Demo](http://codepen.io/syndicatefx/pen/jPxXpz)